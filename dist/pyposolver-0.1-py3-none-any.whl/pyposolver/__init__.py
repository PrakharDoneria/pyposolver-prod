# pyposolver/__init__.py

from . import maths
from . import physics
